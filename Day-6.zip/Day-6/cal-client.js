const request = require('request');

const options = {
  method: 'GET',
  url: 'https://calapi.p.rapidapi.com/add/10/5',
  headers: {
    'x-rapidapi-host': 'calapi.p.rapidapi.com',
    'x-rapidapi-key': 'c80d44a884mshf62a82eb68f858fp109d32jsnf8b874d17bef',
    useQueryString: true
  }
};

request(options, function (error, response, body) {
	if (error) throw new Error(error);

	console.log(body);
});