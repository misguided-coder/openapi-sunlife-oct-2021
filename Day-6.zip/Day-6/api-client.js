const request = require('request');

const options = {
  method: 'GET',
  url: 'https://airport-info.p.rapidapi.com/airport',
  qs: {iata: 'MAA'},
  headers: {
    'x-rapidapi-host': 'airport-info.p.rapidapi.com',
    'x-rapidapi-key': 'c80d44a884mshf62a82eb68f858fp109d32jsnf8b874d17bef',
    useQueryString: true
  }
};

request(options, function (error, response, body) {
	if (error) throw new Error(error);

	console.log(body);
});