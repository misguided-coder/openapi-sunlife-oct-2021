import java.net.http.*;
import java.net.*;

public class ApiClient {

	public static void main(String args[]) throws Exception {
		
	
		 HttpRequest request = HttpRequest.newBuilder()
		.uri(URI.create("https://airport-info.p.rapidapi.com/airport?iata=PNQ"))
		.header("x-rapidapi-host", "airport-info.p.rapidapi.com")
		.header("x-rapidapi-key", "c80d44a884mshf62a82eb68f858fp109d32jsnf8b874d17bef")
		.method("GET", HttpRequest.BodyPublishers.noBody())
		.build();
		HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());

		System.out.println(response.body());
	}

}